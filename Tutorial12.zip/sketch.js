/* eslint-disable no-undef, no-unused-vars */

// Constantes para las URLs de los modelos 3D y las texturas
const URL_3D_1 = "Modelo3D/Mario Object.obj";
const URL_3D_2 = "Modelo3D/bowser.obj";

// Variables donde se almacenan los modelos 3D
let model3D_1;
let model3D_2;

// Variables donde se almacenan las texturas
let textureImg_1;
let textureImg_2;
let textureImg_3;

// Función de precarga
function preload() {
  // Carga el primer modelo 3D y su textura
  model3D_1 = loadModel(URL_3D_1, true);
  textureImg_1 = loadImage("Modelo3D/Mario.png");

  // Carga el segundo modelo 3D y su textura
  model3D_2 = loadModel(URL_3D_2, true);
  textureImg_2 = loadImage("Modelo3D/bowser.png");

  textureImg_3 = loadImage("Modelo3D/Castillo.png");
}

// Función de configuración
function setup() {
  // Crea un canvas con soporte para 3D del tamaño de la ventana del navegador
  createCanvas(windowWidth, windowHeight, WEBGL);
  // Determina que se van a utilizar los grados como unidad de medición
  angleMode(DEGREES);
}

// Función de pintado
function draw() {
  // Establece el color de fondo
  background(200);

  // Dibuja el primer modelo 3D
  push();
  translate(-100, 0); // Desplaza el modelo hacia la izquierda
  rotateY(frameCount);
  texture(textureImg_1);
  scale(1.5);
  rotateX(180);
  model(model3D_1);
  pop();
  // Dibuja el segundo modelo 3D
  push();
  translate(100, 0); // Desplaza el modelo hacia la derecha
  rotateY(-frameCount); // Rotación en sentido contrario para un efecto interesante
  texture(textureImg_2);
  scale(1.5);
  rotateX(180);
  model(model3D_2);
  pop();
  texture(textureImg_3);
  box(width / 1);

  // Dibuja el segundo modelo 3D
  push();
  translate(100, 0); // Desplaza el modelo hacia la derecha
  rotateY(-frameCount); // Rotación en sentido contrario para un efecto interesante
  scale(1.5);
  rotateX(180);
  pop();
  texture(textureImg_3);
  box(width / 1);
}

// Se llama si el tamaño de la ventana del navegador web cambia
windowResized = function () {
  // Redimensiona el tamaño del lienzo al tamaño de la ventana del navegador web
  resizeCanvas(windowWidth, windowHeight);
};
