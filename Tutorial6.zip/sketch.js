/* eslint-disable no-undef, no-unused-vars */

// Declaraciones

// Variable donde se almacena el lienzo de p5
let canvas;
// Variable que almacena el alto del lienzo
let canvasHeight;
// Variable que almacena el ancho del lienzo
let canvasWidth;

// Contante con la URL de la imagen que se va a pintar.
// Al ser una constante, su identificador está escrito con cada palabra en
// mayúscula sostenida y cada palabra separada por un guión bajo
const URL_IMAGEN = "imagen/ASM - Tutorial 6 - Imagen.jpg";

// Variable que va a contener la imagen que se va a pintar.
// Al ser una variable, su identificador está escrito en notación 'CamelCase'
// (cada palabra inicia con una letra mayúscula y el resto de letras en minúscula,
// excepto la primera palabra que es mayúscula sostenida; no hay espacios ni
// guiones entre palabras)
let imagenConejo;
let otraImagen;

// Posición de la imagen
let imagenX = 0;
let imagenY = 0;

// FUNCIÓN DE PRECARGA DE LOS RECURSOS
function preload() {
  // Se carga la imagen y se asigna a la variable
  imagenConejo = loadImage(URL_IMAGEN);
}

// FUNCIÓN DE CONFIGURACIÓN
function setup() {
  // Asigna el alto del lienzo
  canvasHeight = windowHeight - 155;
  // Asigna el ancho del lienzo
  canvasWidth = windowWidth;
  // Crear un lienzo (área de dibujo) del tamaño de la ventana del navegador Web
  canvas = createCanvas(canvasWidth, canvasHeight);
  // Adiciona el lienzo al div con el atributo id igual a canvas-container
  canvas.parent("canvas-container");
  // Cambia la cantidad de cuadros que se muestran por segundo a 2
  frameRate(2);

  // Carga otra imagen desde la web
  otraImagen = loadImage(
    "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxEHBhUSExIVFhIVFRgZFxISFxIXFhMYFhcWGBoWFxcYHTQiGBsoGxkVITEhJSorLi4uFyAzOD8uNygtMSsBCgoKDg0OGhAQGDUdHyUtLi8rLSsrLS0tKystLS0vLS0tLS0tLSstKy0tLTctKy01Ky0rLS0tLS0tLTgtKzUrN//AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAwEBAQEBAAAAAAAAAAAABQYHBAMCAQj/xABHEAACAQIDBQUDCQUDDQEAAAAAAQIDEQQFEgYhMUFREyJhcYEHMpEUI0JSYoKhscEVQ3JzklNjoiQlJjM1VGR0srPR0vAW/8QAGAEBAQEBAQAAAAAAAAAAAAAAAAECAwT/xAAkEQEBAAIBAwQCAwAAAAAAAAAAAQIRIQMSMSIjcYFRYRMkQf/aAAwDAQACEQMRAD8A3EAAAAAAAAAAAAAAPLFVvk+GlP6sXL4JsD1BVdgNpJ59l7VbT28LN6dynGSupJct942+ynzLUABEbW4p4LZnETi7SVKVmtzTasmvHecmwOPeP2ahd3lTcqcm22+4+7dvnocH6gWIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4c9loySu+lGo/hCR3ENtnV7HZPFP+4n+MWv1AyvYzGvKcdSr3elSjTqrk6dWKUZeFpxb+6urNtMLyKgsTSq0nwnQt6p3i/6rGu7I455js1QqSd5OmlJ9Zw7sn8U36mcbzY69THUl/KE9qmM+TbNxp861anD0V6kvS0GvUjvZXWdCrWot31QpVlfnrik38NC+6cntcxWrMsPT5QhUqPzdor8memzH+R7VYTpVwkqX3qd5/khb6pCY7wtaUADTkAAAAAAAAAAAAAAAAAAAAAAAAAAAAABXfaHPRsZifGnb4tIsRXPaJHXsZifCCfwlFgZxsnuzG/SMfxkv/BfPZvU05bXov9ziakPS91+pQNlpfPy/lx/Bl32IfZbUY+HKXY1F5yVTU/xRyxvrr1dWe1jflT/aPX+VbY1o/wBnRp07eMl2n5TRN0n2W0OAl9WvUj/XS0/qVzP12+3mJvzxFNekYU1+SLA/9q4P/ml+URlfXFwns5VpwAOryAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARW1OFeN2bxFNcZUZ28XpbX4kqAMH2UrKWJj0lTkvhZ/kmX/ZN/wCmNX7WFpv4NIotfL//AM5tXKhwhCopQ/lVU4xt4JO33WXfZB32vqeGFj/3Ecte59PXld9D7VLN46faJiF/xEH8aMJfqTFOWvaXBQ/vpS+EU/0Zx7Y0PkftFcnwqqjO/jp7F/8ASvidmzdN43b+m1woQk309yUfzqr+klnuRcb/AF78tRAB2eMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQPaxlanhKWKS71OSpzfWFR2j8JuNv4n1IrYvOY4LEYrE1mr08NTUYqydVpz7sU3vk3GO7rItPtNxMKOys4STcqs6cYRXWNSM3LySi36GL55SlVpQ0vTN1IxU1xgptanHo7In+tzfbpM7WbRzznG0a06bhopuE3G1k3LXrW/3UreTTNA9lWC1ZdPFt3daTUX1hBu8vNz1eiiZpTp6aCi5OVl7zsm/F25ktsrndXZ7N3PtJPDTt2lD6K4qVSK5T917uNmnxTRbLrUbeD5pzVSmpJ3TSaa5p8GfRXMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABnPtXqv5Th4ctNSVvG9NL9ShygpWuuDuvBrmXz2qU3UzLCqKvKSqRjFWvJt07JX9SJw2xOJqQvOpSg/q9+b9Wkkn5XHbb4dMbNKjRrydr2d9/dveKvu1LpwWrqeuIk40XZNvgrJt3e69lxtx9C6YLIqOTScqkbT+R1qFTsE5QxClLtIzcX39a370mt/FFQw7UasO0hKXDVTV4ympxcWo35tSdnwvYlx0StU9mWYrHbKwipaux+bTu33ElKnvf2JRLYUXJassmwcFTU46KdOHyes6W6nSgoQ7apF6YVWk33W+KVmldXXCYiOKw0akXeMopp9U1c1ZY516gAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKttHGM9q8Hq95U8RKPu8dNNPjvvpcnutw9H2FN2uzhZntfh40Jr5iah2sbNa5zippdUorS/OS5FyR26d4aUrbjFwyejqqQnLtJPs1TlCMHJK6VRON0/FN8OR7ZTOjn+FoYiNKrVlTkqcqlWVOMnKCdTS7+9Z3a4Lfxe9EptdlVLN8sUarUVCanGcr6IySa77T3RabTfK6IzZjZ6GCquPars03LsaNepODlJadcrNJd3cuvoLLtudvbvfKWoYGnOMsTNOLl85xjeEXFPe0uO5t2fPmWbIo6Mmpb7/Nxd734q/H1ODQtFrK1rWtusuVuh2bPv/N1vq1KsfSNSaivSNl6E6k4c6kgAckAAAAAAAAAAAAAAAAAAAAAAAAADhzrNqOSZfKtWlphH1cm+EYrm2B1YivHDUHOclGEVeUpNJRS5tvgZVtht7PN5Sw+DcoUr2nX4SqLmoc4x8dzduS3uC2j2hxG1eIvP5vDp3hRi93hKX1pePBcur4qdNU42S3EtbmKU2RwqntDQil3YOU2uihCVv8TgakUr2e4LVOpXa3f6uL6vdKbXh7i80y6nfpzWJfLxxVV0IXUXJfSUd8kuqX0vFcel+B4YfGRq92lTl5unOnCPnqSv5JP0O0G0CM2K2khjcZXws1oq061Zxv8AvI9pJ/1K/DpZ9bSZme3OElk+00cTBuKrWeqLs4VYJJtdHZRf9RjqeBtIK1sZtQs9w2ido4iC70VuU1/aR8Oq5PwavZTiyAAAAAAAAAAAAAAAAAAAAAAAA8sTiIYXDyqTkowinKUnwSW9tmHbR55ParNO1leNCF1Sovgl9eS+s+fThyd7v7XsylSyulhoOzrzvP8Alw5esnD0i1zM8jFQjZcESt4w4I/MowtTPcxjTpuyb3PfwVtVWS+quS5trqrcGZVtcuzXDjL9I/q/TqarsZkf7Iy1OS+eqJOX2Y8Yw/V+LfRGsMd1q1M4HCQwOEjTgrQirLr5t823vb6s9wD0MAAKBDbXZP8AtvI500r1F36f8cU7LwunKP3iZBLNjFsjzGeHqRqQk41abvF77rlZrpa6a8zctnM5hnmVRqx3S4The+ia4xvzXNPmmmY9tvl/7I2o1RVqdZa1bhqbtUj8bS++S/s/ztZbtAqbmtFe0JRut0/3btyd24+OpdEeazV0t5jXgAGAAAAAAAAAAAAAAAAAAAAABnW1lCOZbX96mqioUZKKlOcYKSh2r1KO+Ts4K10rS5vh64nZOGKwlW1GlFwnKMZYdVIT7qi76ZScZ77rS7buDTOvLqSr7RVNX0p4iLfg5Sj+UY/AteGo9jq3+9Ny8tVgsYf7P8r/AGrtApzV40vnZbmk537is+Savb7CNdIWNDBSqVvklCUK7qSvUgpQiqmtpze+1tSk7W324byb5nbpzhX4ADoAAAHxXqqhScnwSu7Jt+iXF+B9nxXpKvRcXezVrp2a8U+T5kERnGRSz/F0IzoSXZVJSkq2ns9LpyVpOEnrWvQ9Ke+2+yuduPyapGSglRlC0HGLoQUINVYqVtLUo2i1KLUrpx5nZRxmIjjqMZVISjKTi1Gm4tpU5y1NuTs7xXBW3+JO3OGW98ojshxM8RgrVVarBtSTd+7dunK/O8NLv1utzTRJHDhu9mtVrglTi/NKUrfCUfidxlAAAAAAAAAAAAAAAAAAAAABTs1pvKdou0XuVJa4+aSU4ee7V96XQsjxsPk8aid4SaWpcFd2u/WyfQgvadKVPY+pKLalGdJqS4xfaw3r0b+JmOA29xeXYWpHRQnCafcnCelSas5WU+fOO5eV3dtY0ylhPkGf14/Rq2qx8byetek3f76O8rWR46pXxlNVKjmo05Rg5JX72l95r3vcVv1LKejHwAANKAAAAAOdYtYLMdcoyk3CMKVl3XOcpak5cIN2pq79ONhTxkbRipqo41HKo4O/a1/eVGnv4J2bvuioxvzt9ugsXjqVNpSjdzlGSumoJ2v9+UH6E9ChCE9SjFOyjdJJ6VwV+ngcM/KV5Zfh3hsPaTvOTcptc5Sd36LgvBI6QDCAAAAAAAAAAAAAAAAAAAAACK2py55ts9Xor3p03p/iW+P4pH87e9Hz5Pj6n9PGL+03Zl5TmjxFOPzFaV3b93Vd3JPopcV4uS6Xlaxr72bxrqZdSkn34Wi/4oWV/VJP1NCweJji6ClH1XR9GYrkeZ/s3Eu9+znbVb6LXCaX5+HkXzA42WHkpwkrNecZL/7md8MtwXQEVhc8p1FaV4v4x+KO+ni6dRbpxfqjY9gfDqxX0l8UeNTMKVPjUj6O/wCRR0huy8Or4LzIfF7Q0qFNtXaS3ydoxXi2ziliZ5hT1VlKFC11TtVgqnR1KkY9yHO17vnZbnNi25HRclKtLjUsoJq2mmr23PnJty8nFciVKvgMVWwGJUpqPYSXe01alXQ3bTNdpG+nrZ23p23NloOGW98sgAMgAAAAAAAAAAAAAAAAAAB4YzFxwdHVK/GySTcpN8EkuLPcr+bL9oY9wbahRa3QlKLlOUd95Rd7KMkrLjqd+RZN0dTzaf8Au07fx0b/AA1W/Eis32qwWiWHxVKrGM474zpOcZR6p0277+a4M8amEpwxCjTo05TSUnOpdqCbdm27uUnZ2S6cVuux+UvNKOiu4SjxUoQlCcJdYtzfr1Ol6f4XTJM+wtDC49rD1J1KL3xlUhOEo8e49SWq3WyPnKM2nlsrW1UnxhzTe+8OniuD8C7YjYWqpPRVpzj9tSi/W10/wOSOxFONW1XEUov+zpRlOo/KN7/4WY7co1w+aGcYfEJWqxu/oy7svLS95KrL8RVoOcMNVmkr8FG6XRVGnL0TJTKNj6MKemnh5RUrKWIrq1RRum1CL3pu1uEeN99rO+LcjVysZY28bpe+EU+jqU015pkjhMJUxcE9dCCa3a6im/6Yf+xqDpxb4L4I/HRi/or4IneKZlmR0aNRTlPtqid1KWnTB9YQW5ebu/EmalRUldtRXVu34sk6uV4es+9RpS/ihB/mj5pZTh6NTVGhSUlwapwTXrY1/J+javYDCzxdKpThTlGjKclGclphGnKMb6E98ry7Rqytv423FtitMbH6DnctoAAgAAAAAAAAAAAAAAAAAAAReNyp1cS6lOpolJLUpR1Qlbcna6adt109+697K0oBLoVv9m4nB15TtCsp6bqn83KLirKynJqSt9pWtzuekMPicQ7KmqS5yqyjKXpCm2n6yRYAa76IqnkVN76rlVf23aHkqcbR+Kb8SQoYaGGjaEIxXSKS/I9QZ2AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/2Q==",
  );
}

// FUNCIÓN DONDE SE PROGRAMA LA FUNCIONALIDAD
function draw() {
  // Limpia el fondo del lienzo
  clear();

  // Pinta la imagen original en la posición especificada
  image(imagenConejo, imagenX, imagenY, 384, 579);

  // Pinta la otra imagen al lado de la primera
  image(otraImagen, imagenX + imagenConejo.width, imagenY, 384, 579); // Ajusta la coordenada x para la segunda imagen

  // Genera un número aleatorio entero entre 0 y 7
  let filtro = Math.round(random(0, 7));
  // Aplica el filtro a la imagen original
  switch (filtro) {
    case 0:
      filter(THRESHOLD);
      break;
    case 1:
      filter(GRAY);
      break;
    case 2:
      filter(OPAQUE);
      break;
    case 3:
      filter(INVERT);
      break;
    case 4:
      filter(POSTERIZE, 3);
      break;
    case 5:
      filter(DILATE);
      break;
    case 6:
      filter(BLUR, 3);
      break;
    default:
      filter(ERODE, 3);
      break;
  }
}

// CAMBIA EL TAMAÑO DEL LIENZO SI LA VENTANA DEL NAVEGADOR WEB CAMBIA DE TAMAÑO
windowResized = function () {
  // Asigna el alto del lienzo
  canvasHeight = windowHeight - 155;
  // Asigna el ancho del lienzo
  canvasWidth = windowWidth;
  // Redimenciona el tamaño del lienzo al tamaño del canvas
  resizeCanvas(canvasWidth, canvasHeight);
};

// FUNCIÓN QUE SE LLAMA AL PRESIONAR UNA TECLA
function keyTyped() {
  // Verifica que la tecla presionada es la f
  if ("f" === key) {
    // Llama una vez a la función draw
    redraw();
  }
  // Muestra la tecla presionada por consola
  console.log(key);
}

// FUNCIÓN QUE SE LLAMA AL PRESIONAR UNA TECLA
function keyPressed() {
  // Mueve la imagen según las teclas de flechas
  if (keyCode === LEFT_ARROW) {
    imagenX -= 10;
  } else if (keyCode === RIGHT_ARROW) {
    imagenX += 10;
  } else if (keyCode === UP_ARROW) {
    imagenY -= 10;
  } else if (keyCode === DOWN_ARROW) {
    imagenY += 10;
  } else if (key === "f" || key === "F") {
    // Aplica un filtro diferente a cada imagen al presionar la tecla "f"
    // Puedes implementar lógica para alternar entre diferentes filtros para cada imagen aquí
  }
}
