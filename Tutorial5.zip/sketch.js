/* eslint-disable no-undef, no-unused-vars */

// Variable donde se almacena el lienzo de p5
let canvas;
// Variable que almacena el alto del lienzo
let canvasHeight;
// Variable que almacena el ancho del lienzo
let canvasWidth;

// Posición horizontal actual del rectángulo móvil
let posXRectangulo;

// Posición vertical actual del cuadrado móvil
let posYCuadrado;

// FUNCIÓN DE CONFIGURACIÓN
function setup() {
  // Asigna el alto del lienzo
  canvasHeight = windowHeight - 155;
  // Asigna el ancho del lienzo
  canvasWidth = windowWidth;
  // Crear un lienzo (área de dibujo) del tamaño de la ventana del navegador Web
  canvas = createCanvas(canvasWidth, canvasHeight);
  // Adiciona el lienzo al div con el atributo id igual a canvas-container
  canvas.parent("canvas-container");
  // Cambia la cantidad de cuadros que se muestran por segundo a 2
  frameRate(2);

  // Inicializa la posición horizontal del rectángulo móvil
  posXRectangulo = canvasWidth - 70;

  // Inicializa la posición vertical del cuadrado móvil
  posYCuadrado = 0;
}

// FUNCIÓN DONDE SE PROGRAMA LA FUNCIONALIDAD
function draw() {
  // Pinta el fondo del color guardado en la variable 'colorFondo'
  background(201, 218, 248); // Color de fondo fijo
  // Define el ancho de la línea de borde de la figura
  strokeWeight(4);

  // Dibuja un cuadrado en la posición vertical actual de tamaño 100x100 con color aleatorio
  let colorCuadrado = color(random(0, 255), random(0, 255), random(0, 255));
  fill(colorCuadrado);
  let colorBordeCuadrado = generarColorDiferente(colorCuadrado);
  stroke(colorBordeCuadrado);
  square(0, posYCuadrado, 100);

  // Dibuja un círculo de diámetro 20 en el centro del lienzo con color aleatorio
  let colorCirculo = color(random(0, 255), random(0, 255), random(0, 255));
  fill(colorCirculo);
  let colorBordeCirculo = generarColorDiferente(colorCirculo);
  stroke(colorBordeCirculo);
  circle(canvasWidth / 2, canvasHeight / 2, 20);

  // Dibuja un rectángulo de 50x80 en la posición horizontal actual con color aleatorio
  let colorRectangulo = color(random(0, 255), random(0, 255), random(0, 255));
  fill(colorRectangulo);
  let colorBordeRectangulo = generarColorDiferente(colorRectangulo);
  stroke(colorBordeRectangulo);
  rect(posXRectangulo, canvasHeight - 100, 50, 80);

  // Actualiza la posición horizontal del rectángulo móvil
  posXRectangulo -= 10;
  if (posXRectangulo < -50) {
    posXRectangulo = canvasWidth;
  }

  // Actualiza la posición vertical del cuadrado móvil
  posYCuadrado += 10;
  if (posYCuadrado > canvasHeight) {
    posYCuadrado = -100;
  }
}

// Función que genera un color aleatorio diferente al color dado
function generarColorDiferente(colorActual) {
  let nuevoColor;
  do {
    nuevoColor = color(random(0, 255), random(0, 255), random(0, 255));
  } while (colorActual.toString() === nuevoColor.toString());
  return nuevoColor;
}
