var typed = new Typed(".auto-type", {
  strings: [
    "Para una mejor experiencia de realidad aumentada",
    "Haz clic en este botón",
  ],
  typeSpeed: 30,
  backSpeed: 10,
  loop: true,
  showCursor: true,
});
// Fin primera Parte //
