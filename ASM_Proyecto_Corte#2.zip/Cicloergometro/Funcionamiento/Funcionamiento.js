document.addEventListener("DOMContentLoaded", function () {
  var img = document.getElementById("secSecImg");
  img.classList.add("fadeIn");
});
